# Umamusume PT-BR para Hachimi Edge (estrutura inicial)

Este é um esqueleto de repositório para iniciar uma tradução comunitária de Umamusume: Pretty Derby (servidor japonês), pensado para o formato de repositórios do Hachimi Edge.

## Estado atual

- Estrutura inicial compatível com o formato documentado de `localized_data`.
- Arquivos JSON vazios de exemplo.
- **Ainda não contém traduções jogáveis** e não está publicado no índice do Hachimi Edge.
- Não instalar como se fosse uma tradução completa.

## Próximas etapas

1. Validar a configuração contra uma cópia atual de um repositório Hachimi Edge.
2. Obter/produzir traduções próprias e verificar as permissões antes de reutilizar dados de outros projetos.
3. Preencher os dicionários no formato exato esperado pelo Hachimi Edge.
4. Testar no Android, incluindo fonte, quebra de linha e diálogos.
5. Publicar num repositório Git acessível e enviar o projeto para o índice do Hachimi Edge.

## Estrutura

```text
localized_data/
  info.json
  config.json
  localize_dict.json
  hashed_dict.json
  text_data_dict.json
  character_system_text_dict.json
  race_jikkyo_comment_dict.json
  race_jikkyo_message_dict.json
  assets/
```

Consulte o guia oficial de configuração de repositórios:
https://hachimi.noccu.art/docs/translation-guide/repo-config
